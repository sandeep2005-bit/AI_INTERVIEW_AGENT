let currentQuestion="", currentTopic="Python", timer=null, seconds=60, scores=[], started=false;

function $(id){return document.getElementById(id)}
function startInterview(){
  currentTopic=$("topic").value; seconds=Number($("duration").value);
  scores=[]; started=true; $("answer").disabled=false; $("submitBtn").disabled=false;
  $("answered").textContent="0"; $("best").textContent="0"; $("words").textContent="0"; $("avgScore").textContent="0";
  nextQuestion();
}
async function nextQuestion(){
  if(!started)return;
  clearInterval(timer);
  $("feedback").classList.add("hidden");
  $("answer").value="";
  $("answer").focus();
  const r=await fetch("/api/question",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic:currentTopic})});
  const d=await r.json(); currentQuestion=d.question;
  $("question").textContent=currentQuestion; $("topicLabel").textContent=currentTopic.toUpperCase();
  $("questionNo").textContent="Question "+(scores.length+1);
  seconds=Number($("duration").value); $("time").textContent=seconds;
  timer=setInterval(()=>{seconds--; $("time").textContent=seconds;if(seconds<=0){clearInterval(timer);submitAnswer()}},1000);
}
async function submitAnswer(){
  if(!started || !$("answer").value.trim())return;
  clearInterval(timer); $("submitBtn").disabled=true;
  const r=await fetch("/api/evaluate",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({topic:currentTopic,question:currentQuestion,answer:$("answer").value})});
  const d=await r.json(); if(d.error){alert(d.error);return}
  scores.push(d.score); const avg=Math.round(scores.reduce((a,b)=>a+b,0)/scores.length);
  $("avgScore").textContent=avg; $("answered").textContent=scores.length;
  $("best").textContent=Math.max(...scores); $("words").textContent=d.word_count;
  $("scoreBar").style.width=avg+"%"; $("levelText").textContent=d.level+" — "+d.feedback;
  $("feedback").textContent="Score: "+d.score+"/100 • "+d.level+" • "+d.feedback;
  $("feedback").classList.remove("hidden"); $("submitBtn").disabled=false;
}
$("answer").addEventListener("keydown",e=>{if(e.ctrlKey&&e.key==="Enter")submitAnswer()});
