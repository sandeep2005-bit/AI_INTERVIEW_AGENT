# 🤖 AI Interviewer Agent

A colorful, beginner-friendly **AI Interviewer Agent** built with Flask. It provides a browser-based technical interview experience with domain selection, timed questions, answer evaluation, feedback and a live score dashboard.

## ✨ Features

- 🎯 Python, DSA, AI/ML and Web Development interview domains
- ⏱️ Configurable 60/90/120 second timer
- 🧠 Local rule-based evaluation model (works without an API key)
- 📊 Live average score, best score, answer count and word count
- 💬 Instant feedback after every answer
- 🎨 Modern responsive dark/neon interface
- 🔌 REST-style Flask endpoints
- 🧑‍💻 Easy to extend with OpenAI/Ollama or another LLM later

## 🚀 Run locally

```bash
python -m venv .venv
```

Windows:
```bash
.venv\Scripts\activate
```

Install:
```bash
pip install -r requirements.txt
```

Start:
```bash
python app.py
```

Open **http://127.0.0.1:5000**

## 📁 Project structure

```text
ai_interviewer_agent/
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
├── templates/
│   └── index.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── app.js
```

## 🧠 About the model

The included evaluator is deliberately API-free so the repository runs immediately. It scores answers using:

1. Answer length / completeness
2. Relevant technical keywords
3. Explanation/example structure

For a production version, replace `score_answer()` with an LLM-based evaluator and keep the same `/api/evaluate` interface.

## 🔐 Publishing to GitHub

```bash
git init
git add .
git commit -m "Initial AI Interviewer Agent"
git branch -M main
git remote add origin YOUR_GITHUB_REPOSITORY_URL
git push -u origin main
```

Do **not** commit API keys or `.env` files.

## 🌟 Suggested repository description

> AI Interviewer Agent — a colorful Flask-based technical interview simulator with timed questions, answer evaluation, instant feedback and live performance analytics.

## 📌 Future enhancements

- LLM-generated adaptive questions
- Voice input and speech-to-text
- Resume-based interview generation
- Webcam/proctoring module
- PostgreSQL/MySQL candidate history
- Authentication and admin dashboard
- PDF interview report
- Difficulty adaptation based on previous answers
