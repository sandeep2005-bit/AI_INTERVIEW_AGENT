from flask import Flask, render_template, request, jsonify
import random
import re

app = Flask(__name__)

QUESTION_BANK = {
    "Python": [
        "What is the difference between a list and a tuple in Python?",
        "Explain exception handling in Python with an example.",
        "What are decorators in Python and why are they useful?",
        "How does a dictionary work in Python?"
    ],
    "DSA": [
        "What is the time complexity of binary search?",
        "Explain the difference between a stack and a queue.",
        "What is a linked list and when would you use one?",
        "What is the difference between BFS and DFS?"
    ],
    "AI/ML": [
        "What is supervised learning? Give two examples.",
        "Explain overfitting and two ways to reduce it.",
        "What is the difference between classification and regression?",
        "Why is feature scaling useful in machine learning?"
    ],
    "Web Development": [
        "What is the difference between GET and POST requests?",
        "Explain the role of HTML, CSS and JavaScript in a web application.",
        "What is a REST API?",
        "What is the purpose of a database in a web application?"
    ]
}

KEYWORDS = {
    "Python": {
        "list": ["mutable", "ordered", "square brackets"],
        "tuple": ["immutable", "ordered", "parentheses"],
        "exception": ["try", "except", "finally", "error"],
        "decorator": ["function", "wrapper", "@"]
    },
    "DSA": {
        "binary": ["log", "o(log", "sorted", "divide"],
        "stack": ["lifo", "last in", "push", "pop"],
        "queue": ["fifo", "first in", "enqueue", "dequeue"],
        "linked": ["node", "pointer", "next", "dynamic"],
        "bfs": ["queue", "breadth"],
        "dfs": ["stack", "depth", "recursion"]
    },
    "AI/ML": {
        "supervised": ["label", "labeled", "classification", "regression", "training"],
        "overfit": ["training", "validation", "regularization", "dropout", "data"],
        "classification": ["class", "category", "label"],
        "regression": ["continuous", "numeric", "value"],
        "scaling": ["standardization", "normalization", "range", "scale"]
    },
    "Web Development": {
        "get": ["retrieve", "query", "url", "post", "body"],
        "html": ["structure", "css", "style", "javascript", "behavior"],
        "rest": ["http", "api", "resource", "get", "post", "put", "delete"],
        "database": ["store", "data", "query", "persistent"]
    }
}

def score_answer(answer, topic, question):
    text = answer.lower().strip()
    words = re.findall(r"[a-zA-Z]+", text)
    length_score = min(len(words) / 80, 1.0) * 35

    topic_terms = set()
    for key, vals in KEYWORDS.get(topic, {}).items():
        if key in question.lower():
            topic_terms.update(vals)
    hits = sum(1 for term in topic_terms if term.lower() in text)
    keyword_score = min(hits / max(len(topic_terms), 3), 1.0) * 45

    structure = 20 if any(x in text for x in ["because", "example", "for example", "therefore"]) else 8
    total = round(min(length_score + keyword_score + structure, 100))
    if total >= 80:
        level = "Excellent"
    elif total >= 60:
        level = "Good"
    elif total >= 40:
        level = "Needs Improvement"
    else:
        level = "Beginner"

    feedback = (
        "Strong answer. Add a small real-world example to make it even clearer."
        if total >= 80 else
        "Good foundation. Explain the key concept more directly and include an example."
        if total >= 60 else
        "Try using technical keywords, a clear definition, and one example."
    )
    return total, level, feedback

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/question", methods=["POST"])
def question():
    data = request.get_json() or {}
    topic = data.get("topic", "Python")
    questions = QUESTION_BANK.get(topic, QUESTION_BANK["Python"])
    return jsonify({"question": random.choice(questions), "topic": topic})

@app.route("/api/evaluate", methods=["POST"])
def evaluate():
    data = request.get_json() or {}
    answer = data.get("answer", "")
    topic = data.get("topic", "Python")
    question_text = data.get("question", "")
    if not answer.strip():
        return jsonify({"error": "Please enter an answer."}), 400
    score, level, feedback = score_answer(answer, topic, question_text)
    return jsonify({
        "score": score,
        "level": level,
        "feedback": feedback,
        "word_count": len(re.findall(r"\b\w+\b", answer))
    })

if __name__ == "__main__":
    app.run(debug=True)
